# Calculadora de média

A Pen created on CodePen.io. Original URL: [https://codepen.io/stefanisantos01/pen/jOxPzVY](https://codepen.io/stefanisantos01/pen/jOxPzVY).

