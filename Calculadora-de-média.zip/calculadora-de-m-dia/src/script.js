var nome = "Stefani" 
var notaDoPrimeiroBimestre = 9
var notaDoSegundoBimestre = 7
var notaDoTerceiroBimestre = 4
var notaDoQuartoBimestre = 2

var notaFinal = (notaDoPrimeiroBimestre + notaDoSegundoBimestre + notaDoTerceiroBimestre + notaDoQuartoBimestre) / 4

var notaFixada = notaFinal.toFixed(1)


console.log("Bem vindo " + nome)
console.log(notaFixada)

//para fazer um comentario

//Revisao
//Variáveis.strings.console.log.tofixed,operaçoes matematicas,concatenação